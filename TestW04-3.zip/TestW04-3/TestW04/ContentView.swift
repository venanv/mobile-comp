import SwiftUI

struct ContentView: View {
    var asean = ["Indonesia", "Singapore", "Malaysia", "Laos", "Philipines", "Cambodia", "Myanmar", "Thailand", "Brunei", "Vietnam"]
    
    @State private var correctAnswer = 0
    @State private var wrongAnswer = 0
    @State private var showingResult = false
    @State private var userScore = 0
    @State private var questionNumber = 1
    @State private var usedFlags = [String]()
    
    var body: some View {
        ZStack {
            Color.gray.edgesIgnoringSafeArea(.all)
            VStack {
                Text("Pilih Bendera ")
                    .foregroundColor(.black)
                Text(asean[correctAnswer])
                    .foregroundColor(.black)
                Text("Benar : \(userScore)")
                    .foregroundColor(.black)
                Text("Salah : \(wrongAnswer)")
                    .foregroundColor(.black)
                HStack {
                    Spacer()
                    VStack {
                        ForEach(0..<5) { number in
                            Button(action: {
                                flagTapped(number)
                            }) {
                                Image(asean[number])
                                    .resizable()
                                    .frame(width: 80, height: 50)
                            }
                            .padding(.vertical)
                        }
                    }
                    Spacer()
                    
                    VStack {
                        ForEach(5..<10) { number in
                            Button(action: {
                                flagTapped(number)
                            }) {
                                Image(asean[number])
                                    .resizable()
                                    .frame(width:  80, height: 50)
                                }
                            .padding(.vertical)
                        }
                    }
                    Spacer()
                }
                Spacer()
            }
        }
        
        
    }
    
    func resetGame() {
        correctAnswer = Int.random(in: 0..<asean.count)
        wrongAnswer = 0
        userScore = 0
        questionNumber = 1
        usedFlags.removeAll()
    }
    
    func flagTapped(_ number: Int) {
        let selectedFlag = asean[number]
        
        if number == correctAnswer {
            userScore += 1
        } else {
            wrongAnswer += 1
        }
        
        questionNumber += 1
        usedFlags.append(selectedFlag)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
